using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ExifLib")]
[assembly: AssemblyDescription("A Fast Exif Data Extractor for .NET 2.0+")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright � 2009 Simon McKenzie, released under the Code Project Open License (CPOL) 1.02")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: AssemblyVersion("1.7.0.0")]