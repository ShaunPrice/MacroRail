# libusb-win32
This is imported from libusb-win32 Subversion.

libusb-win32 is now in Bug-Fix-Only maintenance mode. It is recommended new project should migrate to libusb-1.0 API and use libusb Windows (http://libusb.info) instead, especially for cross platform project. You can also consider migrating to libusbk (https://sourceforge.net/projects/libusbk/) if your project is for Windows only.

Status: with very limited support

Maintained by Peter Dons Tychsen (developer) and Xiaofan Chen (technical support)

